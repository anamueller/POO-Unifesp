public class Ex5{
    
}