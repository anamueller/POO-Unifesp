public class Ex1{
    public class static void main(String args[]) throws Exception{
        try {
            throw new Exception("Errr");
            int[] a = new int[1];
            System.out.printf(x[2]);
        }
        catch (Exception ex){
            System.out.printf(ex.getMessage());
        }
        System.out.printf("Fim");
    }
}