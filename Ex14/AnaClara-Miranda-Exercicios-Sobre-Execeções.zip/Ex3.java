public class Ex3{
    
}