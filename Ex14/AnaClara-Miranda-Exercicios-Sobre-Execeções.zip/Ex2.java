public class Ex2{
    
}