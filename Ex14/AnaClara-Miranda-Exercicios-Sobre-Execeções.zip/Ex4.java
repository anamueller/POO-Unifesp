public class Ex4{
    
}