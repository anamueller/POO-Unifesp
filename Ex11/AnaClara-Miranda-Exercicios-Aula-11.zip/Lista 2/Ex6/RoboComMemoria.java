public class RoboComMemoria extends RoboAbstrato{
    private int passos;
}