public class RoboPesadoABateria extends RoboABateria{
    private int peso;
}