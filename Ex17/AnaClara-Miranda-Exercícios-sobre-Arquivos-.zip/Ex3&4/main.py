from Edita import Edita as ET

def main():
  ET.ex1('input.txt', 1)
  ET.ex2('ex2_o.txt', 'ex2_d.txt')
  ET.ex4('ex4_1.txt', 'ex4_2.txt')
if __name__ == '__main__':
  main()