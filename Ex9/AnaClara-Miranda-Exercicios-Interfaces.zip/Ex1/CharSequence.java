public interface CharSequence{
    char charAt(int index);
    int length();
    java.lang.CharSequence subSequence(int start, int end);
    String toString();   
}