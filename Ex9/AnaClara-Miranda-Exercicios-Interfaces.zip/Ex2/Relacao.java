public interface Relacao{
    public boolean maiorQue(Object b);
    public boolean menorQue(Object b);
    public boolean igualA(Object b);
}